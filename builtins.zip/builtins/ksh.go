package builtins

import (
	"os"
	"os/exec"
	//"fmt"
)

func KSH() error {
	//fmt.Println("This is KSH command!")
	// Launch a new shell using the 'ksh' command.
	cmd := exec.Command("ksh")
	cmd.Env = append(os.Environ(), "/nfs/home/STUDENTS/grl0038/CSCE4600/Project2/builtins/"+os.Getenv("PATH"))

	// Set the correct output device.
	cmd.Stderr = os.Stderr
	cmd.Stdout = os.Stdout
	cmd.Stdin = os.Stdin

	// Execute the 'ksh' command and return the error.
	return cmd.Run()
}

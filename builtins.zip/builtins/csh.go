package builtins

import (
	//"fmt"
	"os"
	"os/exec"
	//"path/filepath"
)

func CSH() error {
	//fmt.Println("This is CSH command!")
	// Launch a new shell using the 'csh' command.
	cmd := exec.Command("csh")
	//cmd.Env = append(os.Environ(), "PATH="+filepath.Join(".", "builtins")+":"+os.Getenv("PATH"))


	// Set the correct output device.
	cmd.Stderr = os.Stderr
	cmd.Stdout = os.Stdout
	cmd.Stdin = os.Stdin

	// Execute the 'csh' command and return the error.
	return cmd.Run()
}

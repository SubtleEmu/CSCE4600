package builtins

import (
	"os"
	"os/exec"
	//"fmt"
)

func SH(arg ...string) error {
    //fmt.Println("This is SH command!")
    // Launch a new shell using the 'sh' command.
    cmd := exec.Command("sh")

    // Set the correct output device.
    cmd.Stderr = os.Stderr
    cmd.Stdout = os.Stdout
    cmd.Stdin = os.Stdin

    // Execute the 'sh' command and return the error.
    return cmd.Run()
}

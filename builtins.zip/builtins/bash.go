package builtins

import (
	"os"
	"os/exec"
	"fmt"
)

func BASH() error {
	// Launch a new shell using the 'bash' command.
	cmd := exec.Command("bash")
	fmt.Println("This is the BASH command!")

	// Set the correct output device.
	cmd.Stderr = os.Stderr
	cmd.Stdout = os.Stdout
	cmd.Stdin = os.Stdin

	// Execute the 'bash' command and return the error.
	return cmd.Run()
}
